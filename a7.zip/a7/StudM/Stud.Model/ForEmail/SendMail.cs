﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stud.Model.ForEmail
{
    public static class SendMail
    {
        public static void mail(EmailCon emailCon)
        {

        }
    }
}
